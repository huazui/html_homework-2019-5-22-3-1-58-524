package sales;

import java.util.ArrayList;
import java.util.List;

public class SalesDao {

	public Sales getSalesBySalesId(String salesId) {
		// TODO Auto-generated method stub
		return new Sales();
	}

	public List<SalesReportData> getReportData(Sales sales) {
		// TODO Auto-generated method stub
		return new ArrayList<SalesReportData>();
	}

}
