package sales;

public class EcmService {

	public void uploadDocument(String xml) {
		// TODO Auto-generated method stub

		
	}

}
