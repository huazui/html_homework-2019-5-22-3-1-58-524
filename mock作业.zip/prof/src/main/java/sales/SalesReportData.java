package sales;

public class SalesReportData {
	
	private boolean confidential;

	public String getType() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isConfidential() {
		return confidential;
	}

	public void setConfidential(boolean confidential) {
		this.confidential = confidential;
	}

}
