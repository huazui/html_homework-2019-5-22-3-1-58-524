package parking;

public interface CarDao {

    public boolean isVip(String carName);
}
